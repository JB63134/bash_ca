#!/usr/bin/env bash
#------------------------------------------------------------------------
# ca  aka .bash_ca           ┌──────┐ │      │ └──────┘
# Main Function: ca                                                                         
# Purpose: Analyzes a Bash command, alias, builtin, keyword, function, or binary
#------------------------------------------------------------------------
# If not running interactively, don't do anything
case $- in
    *i*) ;;
      *) return;;
esac

# shellcheck disable=SC2034
ca_needed_deps=(grep basename file find sed cut head readlink realpath awk ldd getcap perl)
# shellcheck disable=SC2034
ca_optional_deps=(tput fzf batcat bat dpkg rpm pacman)

OLD_PATH="$PATH"

declare -gA __CA_SEEN_ALIASES
declare -gA __CA_SEEN_COMMANDS
declare -gA __CA_SEEN_BUILTINS
declare -gA __CA_SHADOW_SEEN
declare -gA __CA_VISITED          
complete -F _ca_completion ca

ca() {
    # -------------------------
    # LOCAL Variables
    # -------------------------
    local fcmd cmd ctype cmd_path alias_expansion RED GREEN CYAN RESET 
    local depth=${2:-0}
    local cmdline="$*"
    local MAX_DEPTH=8
    local indent
    indent=$(printf "%*s" $((depth * 4)) "")
    
    # -------------------------
    # Colors (tput → ANSI → none)
    # -------------------------
    if command -v tput &>/dev/null && [[ $(tput colors 2>/dev/null) -ge 8 ]]; then
        # Preferred: tput colors
        RED=$(tput setaf 1)
        GREEN=$(tput setaf 2)
        CYAN=$(tput setaf 6)
        YELLOW=$(tput setaf 11)
        BPURP=$(tput setaf 13)
        RESET=$(tput sgr0)
        UNLINE=$(tput smul)
        STOPUNLINE=$(tput rmul)
    else
        # Fallback: ANSI escape sequences
        RED='\033[31m'
        GREEN='\033[32m'
        CYAN='\033[36m'
        YELLOW='\033[93m'
        BPURP='\033[95m'
        RESET='\033[0m'
        UNLINE='\033[4m'
        STOPUNLINE='\033[0m'
    fi
 
    : "${RED:=}"
    : "${GREEN:=}"
    : "${CYAN:=}"
    : "${YELLOW:=}"
    : "${BPURP:=}"
    : "${RESET:=}"
    : "${UNLINE:=}"
    : "${STOPUNLINE:=}"
 
    # -------------------------
    # Set first run variables path etc... keep from running every recursive loop 
    # set new path, clean arrays, and greet user once
    # -------------------------
    if (( depth == 0 )); then
        trap '_ca_restore_path' RETURN
        _ca_add_admin_paths

        #--------------------------
        # Reset arrays on first run
        #--------------------------
        __CA_SEEN_ALIASES=()
        __CA_SEEN_COMMANDS=()
        __CA_SEEN_BUILTINS=()
        __CA_SHADOW_SEEN=()
        __CA_VISITED=()
   
        #--------------------------
        # Greeting
        #--------------------------
        printf "\n╔══════════════════════════════════════════════╗\n"
        printf "║  ca – Bash Command Analyzer                  ║\n"
        printf "╚══════════════════════════════════════════════╝\n"
        
        # -------------------------
        # Check dependencies
        _ca_check_dependencies ca_needed_deps ca_optional_deps 1  || return 1 # 1 = exit if required deps missing
    fi 
    
    # -------------------------
    # Depth guard
    # -------------------------
    (( depth > MAX_DEPTH )) && { 
        printf "%s${RED}Max recursion depth (%d) reached${RESET}\n" "$indent" "$MAX_DEPTH"
        return 1 
    }
    
    # -------------------------
    # Get command or last command
    # -------------------------
    if [[ -n "$1" ]]; then
        read -r -a fcmd <<< "$1"
    else
        read -r -a fcmd <<< "$(fc -ln -1)" || { 
            printf "%s    ↳ ${RED}Failed to get last command${RESET}\n" "$indent"
            return 1
        }
    fi
    cmd="${fcmd[0]}"
    
    # -------------------------------------------------------------------------
    # handle arguments for ca
    # -------------------------------------------------------------------------
    
    local fzffound=0
    if command -v fzf &>/dev/null; then
        fzffound=1
    fi
    
    case "$cmd" in
        -h|--help) _ca_usage; return 0;;
        -v|--version) _ca_ver; return 0;;
        -s|--sourced) printf "\n"; _ca_sourced_files; return 0;;
        -o|--overridden) printf "\n"; _ca_overridden; return 0;;
        -p|--path) printf "\n"; _ca_writable_dir_in_path; return 0;;
        -S|--scan) printf "\n"; _ca_display_scan; return 0;;
        -f|--fzf)
            if (( fzffound == 1 )); then 
                local pick
                pick=$(compgen -A function -A alias -A builtin -A command | sort -u | fzf --prompt="Get help for: ")
                [[ -n "$pick" ]] || return 1
                ca "$pick"
                return 0
            else
                printf "%s    ↳ ${YELLOW}fzf is not installed.${RESET}\n" "$indent"
                printf "\n"
                _ca_usage;
                return 0
            fi  
            ;; 
    esac
    
    # -------------------------------------------------------------------------
    # Handle ca for now, prevent ca from analyzing itself because 
    # it will spam the screen with itself
    # -------------------------------------------------------------------------
    if [[ "$cmd" == "ca" ]]; then
            printf "%s├─ Do you speak spanish?\n" "$indent"
            printf "%s├─ Detected ${CYAN}'%s' ${RESET}\n" "$indent" "$cmd"
            printf "%s    ↳ Showing  ${CYAN}'%s --help'${RESET}:\n\n"  "$indent" "$cmd"
            _ca_usage
            return 0
    fi
    
    # Edge case that fails with type. catch it here to avoid a crash later.
    if [[ "$cmd" == "]" ]]; then
        printf "%s├─ Detected BASH Keyword ${CYAN}'%s' ${RESET}\n" "$indent" "$cmd"
        printf "%s    ↳ ${CYAN}%s${RESET} -- Ends a conditional test expression.\n" "$indent" "$cmd"
        return 0
    fi
    
    # -------------------------------------------------------------------------
    # Split and analyze pipelines, chains, and lists safely
    # -------------------------------------------------------------------------
    if [[ "$cmdline" =~ [\|\&\;] ]]; then
        local segments=()
        _ca_split_top_level_commands "$cmdline" segments

        for seg in "${segments[@]}"; do
            # Get individual commands in the segment (e.g., within a pipeline)
            local subcmds=()
            _ca_parse_commands "$seg" subcmds

            for c in "${subcmds[@]}"; do
                printf "%s${CYAN}↳ Subcommand:${RESET} %s\n" "$indent" "$c"
                ca "$c" $((depth + 1))
            done
        done
        return 0
    fi

    # -------------------------------------------------------------------------
    # Detect command type
    # -------------------------------------------------------------------------
    ctype=$(type -t -- "$cmd" 2>/dev/null)
    if [[ -z "$ctype" ]]; then
        printf "%s├─ ${RED}Unknown or invalid command:${CYAN} '%s'${RESET}\n" "$indent" "$cmd"
        printf "%s    ↳ Check your spelling and try again\n\n" "$indent" 
        return 1
    fi

    # -------------------------------------------------------------------------
    # Handle keywords and provide help statements
    # -------------------------------------------------------------------------
    if [[ "$ctype" == "keyword" ]]; then
        case "$cmd" in
        if|case|for|select|while|until|function|time|[[|coproc)
            printf "%s├─ Detected BASH Keyword ${CYAN}'%s' ${RESET}\n" "$indent" "$cmd"
            printf "%s    ↳ Showing  ${CYAN}'help %s'${RESET}:\n\n" "$indent" "$cmd"
            help "$cmd" 2>/dev/null | sed 's/^/    /'
            return 0
            ;;
        esac
        
        if [[ "$cmd" == "{" ]]; then
            printf "%s├─ Detected BASH Keyword ${CYAN}'%s' ${RESET}\n" "$indent" "$cmd"
            printf "%s    ↳ Showing  ${CYAN}'help %s'${RESET}:\n\n" "$indent" "$cmd"
            help "$cmd" 2>/dev/null | sed 's/^/    /'
            return 0
        fi
        
        case "$cmd" in
            then|else|elif|fi|do|done|in|!|])
                description=""
                case "$cmd" in
                    then) description="Begins the command block for a true condition." ;;
                    else) description="Begins the command block if the condition is false." ;;
                    elif) description="Introduces a new condition if the previous one is false." ;;
                    fi)   description="Ends an if statement." ;;
                    do)   description="Begins the body of a loop or conditional block." ;;
                    done) description="Ends the body of a loop or conditional block." ;;
                    in)   description="Specifies the list to iterate over in a loop." ;;
                    !)    description="Negates the exit status of a command or pipeline." ;;
                esac
            printf "%s├─ Detected BASH Keyword ${CYAN}'%s' ${RESET}\n" "$indent" "$cmd"
            printf "%s    ↳ ${CYAN}%s${RESET} -- %s\n" "$indent" "$cmd" "$description"
            return 0
            ;;
        esac

        if [[ "$cmd" == "esac" ]]; then
            printf "%s├─ Detected BASH Keyword ${CYAN}'%s' ${RESET}\n" "$indent" "$cmd"
            printf "%s    ↳ ${CYAN}%s${RESET} -- Ends a case statement.\n" "$indent" "$cmd"
            return 0
        fi

        if [[ "$cmd" == "}" ]]; then
            printf "%s├─ Detected BASH Keyword ${CYAN}'%s' ${RESET}\n" "$indent" "$cmd"
            printf "%s    ↳ ${CYAN}%s${RESET} -- Ends a group of commands in a block.\n" "$indent" "$cmd"
            return 0
        fi
      
        if [[ "$cmd" == "]]" ]]; then
            printf "%s├─ Detected BASH Keyword ${CYAN}'%s' ${RESET}\n" "$indent" "$cmd"
            printf "%s    ↳ ${CYAN}%s${RESET} -- Ends a conditional test expression.\n" "$indent" "$cmd"
            return 0
        fi
    fi

    # -------------------------------------------------------------------------
    # Builtins
    # -------------------------------------------------------------------------
    if [[ "$ctype" == "builtin" ]]; then
    
        # Special builtins: `builtin` and `command`
        if [[ "$cmd" == "builtin" || "$cmd" == "command" ]]; then    
        
            # Case: user typed plain `builtin` or `command`
            if (( ${#fcmd[@]} == 1 )); then
                printf "%s├─ Detected builtin ${CYAN}'%s' ${RESET}with no command\n" "$indent" "$cmd"
                printf "%s    ↳ Showing  ${CYAN}'help %s'${RESET}:\n\n" "$indent" "$cmd"
                help "$cmd" 2>/dev/null | sed 's/^/    /'
                return 0
            fi

            # Strip wrapper and skip flags
            local subcmd=("${fcmd[@]:1}")
            while [[ "${subcmd[0]}" == -* ]]; do
                subcmd=("${subcmd[@]:1}")
            done

            printf "%s├─ Detected ${CYAN}'%s'${RESET} wrapper\n" "$indent" "$cmd"
            printf "%s    ↳ Showing  ${CYAN}'help %s'${RESET}:\n\n" "$indent" "${subcmd[0]}"
            help "${subcmd[0]}" 2>/dev/null | sed 's/^/    /'
            return 0    
        fi
    
        # Normal builtin
        printf "%s├─ ${CYAN}'%s'${RESET} is a shell builtin\n" "$indent" "$cmd"

        # Enabled/disabled
        local enabled_state="enabled"
        if enable -p 2>/dev/null | grep -qE "^-n ${cmd}\b"; then
            enabled_state="disabled"
        fi
        printf "%s    ↳ Status: Shell builtin is ${CYAN}%s${RESET}\n" "$indent" "$enabled_state"

        # Loadable builtins
        local origin="Core Bash builtin"
        while read -r loaded; do
            # format: enable -f PATH NAME
            builtin_name="${loaded##* }"
            if [[ "$builtin_name" == "$cmd" ]]; then
                origin="Loadable builtin ($loaded)"
                break
            fi
        done < <(enable -a | grep '^enable -f ' || true)

        printf "%s    ↳ Source:  ${CYAN}%s${RESET}\n" "$indent" "$origin"

        # Show help
        printf "%s    ↳ Showing ${CYAN}'help %s'${RESET}:\n\n" "$indent" "$cmd"
        help "$cmd" 2>/dev/null | sed "s/^/$indent        /"

        # Recurse
        local nextcmd=("${fcmd[@]:1}")
        if (( ${#nextcmd[@]} > 0 )); then
            ca "${nextcmd[*]}" $((depth + 1))
        fi
        return 0
    fi
        
    # -------------------------------------------------------------------------
    # Functions
    # -------------------------------------------------------------------------
    if [[ "$ctype" == "function" ]]; then

        #--------------------------- 
        # Enable extdebug temporarily so declare -F includes file/line info
        local was_extdebug=0

        if shopt -q extdebug; then
            was_extdebug=1
        else
            shopt -s extdebug
        fi
        
        read -r _ line file <<< "$(declare -F "$cmd")"

        (( !was_extdebug )) && shopt -u extdebug  # Restore extdebug state if we enabled it
        #---------------------------- 
        
        printf "%s├─ ${CYAN}'%q' ${RESET}is a shell function\n" "$indent" "$cmd"
        
        if [[ "$file" == "main" ]]; then
            printf "%s    ↳ Declared in: ${CYAN}interactive shell (not from a file)${RESET}\n" "$indent"
        else
            printf "%s    ↳ Declared in: ${CYAN}%s (line %s)${RESET}\n" "$indent" "$file" "$line"
        fi
        
        printf "%s    ↳ Showing first 50 lines of function: ${CYAN}%s${RESET}\n\n"  "$indent" "$cmd"     
           
        local func_content
        func_content=$(declare -f "$cmd")
        _ca_highlight_script "$func_content" "$indent" "$file" "$line"
        
        printf "\n%s    ======= End of function preview =======\n" "$indent"   
        return 0
    fi
    
    # -------------------------------------------------------------------------
    # Aliases
    # -------------------------------------------------------------------------
    if [[ "$ctype" == "alias" ]]; then
        # Avoid re-analyzing the same alias (prevents infinite loops)
        [[ -n "${__CA_SEEN_ALIASES[$cmd]}" ]] && return 0
        __CA_SEEN_ALIASES["$cmd"]=1
    
        # Get the alias expansion (strip surrounding quotes)
        local raw
        raw=$(alias "$cmd")
        alias_expansion=${raw#*=}         # remove 'name='
        alias_expansion=${alias_expansion:1:${#alias_expansion}-2}   # trim outer quotes
        # Expand environment vars safely (no command execution)
        alias_expansion=$(_ca_expand_vars "$alias_expansion")
        alias_def=$(alias "$cmd")
        
        printf "%s├─ ${CYAN}'%s' ${RESET}is an alias → resolves to: ${CYAN}%s${RESET}\n" "$indent" "$cmd" "$alias_def"
    
        # Show where alias is defined
        local found_location=""
        local line_number
        
        _ca_sourcedtree
        
        #-----------------------------------------------------
        # Enable nullglob temporarily 
        local nullglob_was=0
        if shopt -q nullglob; then
            nullglob_was=1
        else
            shopt -s nullglob
        fi
           
        for file in "${SOURCED_FILES_LIST[@]}"; do 
             [[ -r "$file" ]] || continue
             if grep -qE "^[[:space:]]*alias[[:space:]]+${cmd}=" "$file"; then
                found_location="$file"
                line_number=$(grep -nE "^[[:space:]]*alias[[:space:]]+$cmd=" "$file" | head -n1 | cut -d: -f1)
                printf "%s    ↳ Defined in: ${CYAN}%s (line %s)${RESET}\n" "$indent" "$file" "$line_number"
             fi
        done
        (( !nullglob_was )) && shopt -u nullglob  # Restore nullglob state if we enabled it
        #-----------------------------------------------------
        
        if [[ -z "$found_location" ]]; then
            printf "%s    ↳ Declared in: ${CYAN}interactive shell (not from a file)${RESET}\n" "$indent"
        fi     
    
        # Handle alias expansion with chain/pipeline parsing
        if [[ "$alias_expansion" =~ [\|\&\;] ]]; then
            local segments=()
            _ca_split_top_level_commands "$alias_expansion" segments

            for seg in "${segments[@]}"; do
                local subcmds=()
                _ca_parse_commands "$seg" subcmds

                for c in "${subcmds[@]}"; do
                    printf "%s${BPURP}    ↳ Alias subcommand:${RESET} %s\n" "$indent" "$c"
                    ca "$c" $((depth + 1))
                done
            done
            return 0
        else
            # No chain/pipeline — analyze normally
            # Resolve only the first token of the alias expansion to avoid arbitrary shells
            read -r -a alias_tokens <<< "$alias_expansion"
            local primary="${alias_tokens[0]}"
            # If primary is a function, recurse; otherwise analyze as external or builtin
            if declare -F "$primary" &>/dev/null; then
                if [[ -z "${__CA_VISITED[$primary]}" ]]; then
                    __CA_VISITED["$primary"]=1
                    ca "$primary" $((depth + 1))
                else
                    printf "%s    ↳ ${CYAN}%s${RESET} already visited — possible cycle\n" "$indent" "$primary"
                fi
            else
                ca "$alias_expansion" $((depth + 1))
            fi
            return 0
        fi
    fi

    # -------------------------------------------------------------------------
    # External commands
    # -------------------------------------------------------------------------
    if [[ "$ctype" == "file" ]]; then
        cmd_path=$(command -v "$cmd") || {
            printf "%s${RED}Command not found: '%s'${RESET}\n" "$indent" "$cmd"
            return 1
        }

        local cmd_real formatted_type file_info
        cmd_real=$(readlink -f "$cmd_path" 2>/dev/null || echo "$cmd_path")
        file_info=$(file -b "$cmd_real")

        formatted_type=$(printf "%s" "$file_info" | sed -E \
            $'s/, interpreter/\\\ninterpreter/g; 
              s/, version/\\\nversion/g; 
              s/, dynamically/\\\ndynamically/g; 
              s/, BuildID/\\\nBuildID/g; 
              s/, for /\\\nfor /g')

        printf "%s├─ ${CYAN}'%s' ${RESET}is an external command\n" "$indent" "$cmd"
        printf "%s    ↳ Path: ${CYAN}%s${RESET}\n" "$indent" "$cmd_path"

        # Detect symbolic link
        if [[ "$cmd_real" != "$cmd_path" ]]; then
            printf "%s    ↳ ${YELLOW}Symbolic link ${RESET}to: ${YELLOW}%s${RESET}\n" "$indent" "$cmd_real"
            cmd_path="$cmd_real"
            printf "%s    ↳ Now Examining: ${BPURP}%s${RESET}\n" "$indent" "$cmd_real"
        fi
        
        local base
        base=$(basename "$cmd_real")
        _ca_show_shadowing "$base" "$cmd_real"
        
        local size_bytes
        size_bytes=$(stat -c %s "$cmd_path")
        printf "%s    ↳ File Size: " "$indent" 

        local kib=1024
        local mib=$((1024 * 1024))
        local gib=$((1024 * 1024 * 1024))
        local tib=$((1024 * 1024 * 1024 * 1024))

        if   (( size_bytes < kib )); then printf "${CYAN}%d B${RESET}\n" "$size_bytes"
        elif (( size_bytes < mib )); then printf "${CYAN}%.1f KB${RESET}\n" "$(echo "$size_bytes / 1024" | bc -l)"
        elif (( size_bytes < gib )); then printf "${CYAN}%.1f MB${RESET}\n" "$(echo "$size_bytes / 1048576" | bc -l)"
        elif (( size_bytes < tib )); then printf "${CYAN}%.1f GB${RESET}\n" "$(echo "$size_bytes / 1073741824" | bc -l)"
        else                         printf "${CYAN}%.1f TB${RESET}\n" "$(echo "$size_bytes / 1099511627776" | bc -l)"
        fi
        
        # Executable Type
        if grep -qiE 'script|text executable' <<< "$file_info"; then
            printf "%s    ↳ Executable Type: ${CYAN}Script / Text executable${RESET}\n" "$indent"
            local first_line interp
            first_line=$(head -n1 "$cmd_path")

            if [[ "$first_line" =~ ^#! ]]; then
                interp="${first_line#\#!}"
                interp="${interp#"${interp%%[![:space:]]*}"}"
            fi

            while IFS= read -r line; do
                printf "%s    ⎟    ${CYAN}%s${RESET}\n" "$indent" "$line"
            done <<< "$formatted_type"

            printf "%s    ↳ Interpreter: ${CYAN}%s${RESET}\n" "$indent" "$interp"

        elif grep -qi 'ELF' <<< "$file_info"; then
            if grep -qi 'statically linked' <<< "$file_info"; then
                printf "%s    ↳ Executable Type: ELF binary - Statically linked\n" "$indent"
            else
                printf "%s    ↳ Executable Type: ELF binary - Dynamically linked\n" "$indent"
            fi

            while IFS= read -r line; do
                printf "%s    ⎟    ${CYAN}%s${RESET}\n" "$indent" "$line"
            done <<< "$formatted_type"

        else
            printf "%s    ↳ Executable Type: Unknown\n" "$indent"
            while IFS= read -r line; do
                printf "%s    ⎟    ${CYAN}%s${RESET}\n" "$indent" "$line"
            done <<< "$formatted_type"
            printf "%s    ⎟       ${YELLOW}%s${RESET}\n" "$indent" "$file_info"
        fi

        # Root privilege detection
        local requires_root=0
        local root_reason=""

        # 1. setuid root
        if [[ -u "$cmd_path" && $(stat -c '%U' "$cmd_path") == "root" ]]; then
            requires_root=1
            root_reason="setuid root binary"

        # 2. capabilities from getcap
        elif command -v getcap &>/dev/null; then
            local caps
            caps=$(getcap "$cmd_path" 2>/dev/null)
            if [[ "$caps" =~ (cap_sys_admin|cap_dac_override|cap_net_admin) ]]; then
                requires_root=1
                root_reason="binary grants elevated capabilities (getcap)"
            fi
        fi

        # 3. known admin commands
        if (( !requires_root )); then
            local root_cmds=(
                mount umount reboot shutdown halt ifconfig iptables ip
                systemctl journalctl modprobe insmod rmmod fdisk mkfs losetup
                parted fsck useradd userdel passwd chown chmod service sysctl
                visudo fstrim swapoff swapon update-grub grub-install blkid
                update-initramfs
            )
            for rcmd in "${root_cmds[@]}"; do
                if [[ "$cmd" == "$rcmd" ]]; then
                    requires_root=1
                    root_reason="known administrative command"
                    break
                fi
            done
        fi
        
        if (( requires_root )); then
            printf "%s    ↳ Requires root privileges: ${YELLOW}%s${RESET}\n" "$indent" "$root_reason"
        fi

        # Dependencies (ELF only)
        local deps
        deps=$(ldd "$cmd_path" 2>/dev/null | sed 's/^[[:space:]]*//')
        if [[ -n "$deps" ]]; then
            printf "%s    ↳ Dependencies:\n" "$indent"
            local unmet_found=0
            while IFS= read -r line; do
                if [[ "$line" =~ "not found" ]]; then
                    unmet_found=1
                    printf "%s    ⎟    ${RED}%s${RESET}\n" "$indent" "$line"
                else
                    printf "%s    ⎟    ${CYAN}%s${RESET}\n" "$indent" "$line"
                fi
            done <<< "$deps"
            (( unmet_found )) && printf "%s        ↳ ${RED}Some dependencies are missing!${RESET}\n" "$indent"
        fi

# Package info
_ca_lookup_package "$cmd_path" "$indent"
        

        # Permissions
        if [[ -x "$cmd_path" ]]; then
            local perms octal owner_grp owner_perm group_perm other_perm risk_color
            local sid=""
            perms=$(stat -c "%A" "$cmd_path")
            octal=$(stat -c "%a" "$cmd_path")
            owner_grp=$(stat -c "%U:%G" "$cmd_path")

            owner_perm="${perms:1:3}"
            group_perm="${perms:4:3}"
            other_perm="${perms:7:3}"

            # Determine risk level
            if [[ ${owner_perm:2:1} =~ [sS] ]]; then
                risk_color="${RED}"      # SUID → high risk
                sid="[SUID]"
            elif [[ ${group_perm:2:1} =~ [sS] ]]; then
                risk_color="${YELLOW}"   # SGID → medium risk
                sid="[SGID]"
            elif [[ ${other_perm} =~ w ]]; then
                risk_color="${RED}"      # world write → very risky
                sid="[World Writable]"  
            else
                risk_color="${GREEN}"    # normal → safe
            fi

            # Highlight the s or S in yellow
            if [[ ${owner_perm:2:1} =~ [sS] ]]; then
                owner_perm="${owner_perm:0:2}${RED}${owner_perm:2:1}${RESET}"
            fi

            if [[ ${group_perm:2:1} =~ [sS] ]]; then
                group_perm="${group_perm:0:2}${YELLOW}${group_perm:2:1}${RESET}"
            fi

            # Output
            printf "%s    ↳ Permissions: %s%s%s (octal: %s%s%s)  %s%s%s\n" \
                "$indent" "$risk_color" "$perms" "$RESET" \
                "$risk_color" "$octal" "$RESET" "$risk_color" "$sid" "$RESET"

            printf "%s    ⎟    ↳ Owner/Group: ${CYAN}%s${RESET}\n" \
                "$indent" "$owner_grp"

            printf "%s    ⎟    ↳ Owner: ${CYAN}%s${RESET}  Group: ${CYAN}%s${RESET}  Others: ${CYAN}%s${RESET}\n" \
                "$indent" "$owner_perm" "$group_perm" "$other_perm"
        fi
       
        local crtime ctime mtime atime
        
        crtime=$(stat -c %w -- "$cmd_path"); [[ "$crtime" == "-" ]] && crtime="(not available)"
        ctime=$(stat -c %z -- "$cmd_path")
        mtime=$(stat -c %y -- "$cmd_path")
        atime=$(stat -c %x -- "$cmd_path")
        
        printf "%s    ↳ Timestamps:\n" "$indent"
        printf "%s    ⎟    ↳ File created (crtime): ${CYAN}%s${RESET}\n" "$indent" "$crtime"
        printf "%s    ⎟    ↳ Last status change (ctime): ${CYAN}%s${RESET}\n" "$indent" "$ctime" 
        printf "%s    ⎟    ↳ Last modified (mtime): ${CYAN}%s${RESET}\n" "$indent" "$mtime"   
        printf "%s    ⎟    ↳ Last accessed (atime): ${CYAN}%s${RESET}\n" "$indent" "$atime"         

        local perlfound=0
        if command -v perl &>/dev/null; then
            perlfound=1
        fi
    
        # Dump script content
        if grep -qiE 'script|text executable' <<< "$file_info"; then
            printf "%s    ↳ Showing first 50 lines of script ${CYAN}'%s'${RESET}:\n" "$indent" "$cmd"
            if (( perlfound == 0 )); then 
                printf "%s    ↳ ${YELLOW}Optional dependency 'perl' missing — syntax highlighting reduced${RESET}\n" "$indent" 
            fi           
            if [[ -r "$cmd_path" ]]; then
                printf "\n"
                _ca_highlight_script "$cmd_path" "$indent" " " " "
                printf "\n%s    ========== End of script preview ========= \n" "$indent"
            fi
            return 0
        else
            printf "%s    └──────────────────────────────────────────\n\n" "$indent"
        fi
        local next_cmd=("${fcmd[@]:1}")
        if (( ${#next_cmd[@]} > 0 )); then
            ca "${next_cmd[*]}" $((depth + 1))
        fi
        return 0
    fi
}

#------------------------------------------------------------------------
# Function: _ca_usage
# Purpose : Display usage information and examples for the `h` command analyzer.
#------------------------------------------------------------------------
_ca_usage() {
    cat <<'EOF'

     Usage:  ca [command]  
     Analyzes a Bash command, alias, builtin, function, or binary — showing where it’s defined,
     how it expands, and what help or documentation is available.

     Options:
           -h --help or h      Show this help text.
           -v --version        Show version information.
           -f --fzf            Use fzf to interactivly search for commands     
           -s --sourced        List all sourced files in the enviroment.
           -o --overridden     List all commands that override another command in the enviroment.
           -p --path           list all directories in $PATH and highlight writable directories.
           -S --scan           Scan for SUID and SGID binaries and World Writable directories.
              
     Examples:
           ca                   # Automatically analyzes your most recent command
           ca awk               # Analyzes 'awk'
           ca ls                # Is 'ls' a builtin, keyword, alias, function, script or binary?
  
EOF
}

#------------------------------------------------------------------------
# Function: _ca_ver
# Purpose : Display version information.
#------------------------------------------------------------------------
_ca_ver() {
    cat <<'EOF'

     ca v1.0.35 — Bash Command Analyzer
     Author : John Blair
          
     MIT License

     Copyright (c) 2025 John Blair

     Permission is hereby granted, free of charge, to any person obtaining a copy
     of this software and associated documentation files (the "Software"), to deal
     in the Software without restriction, including without limitation the rights
     to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
     copies of the Software, and to permit persons to whom the Software is
     furnished to do so, subject to the following conditions:

     The above copyright notice and this permission notice shall be included in all
     copies or substantial portions of the Software.

     THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
     IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
     FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
     AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
     LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
     OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
     SOFTWARE.

EOF
}

#------------------------------------------------------------------------
# Function: _ca_add_admin_paths
# Purpose: Add ~/.local/bin paths safely and temporarily
#------------------------------------------------------------------------
_ca_add_admin_paths() {
    # Save PATH if not already saved 
    if [[ -z "$OLD_PATH" ]]; then
        OLD_PATH="$PATH"
    fi

    local admin_dirs=(
            "$HOME/.local/bin"
            "$HOME/bin/scripts"
            "$HOME/bin"
            "$HOME/.cargo/bin"
            "$HOME/.npm-global/bin"
            "$HOME/.local/share/bash-completion/bin"
            "$BASH_ENV"
            "$CONDA_PREFIX/bin"
            "/flatpak/bin"         
            "/snap/bin"
            "/usr/local/bin"
            "/usr/local/sbin"
            "/usr/local/games"
            "/usr/bin"
            "/usr/sbin"        
            "/usr/games"
            "/bin"
            "/sbin"  
            "/opt/bin"
            "/opt/sbin"         
            )
            
    # Add admin dirs to PATH if missing
    for dir in "${admin_dirs[@]}"; do
        if [[ -d "$dir" && ":$PATH:" != *":$dir:"* ]]; then
            PATH="$PATH:$dir"
        fi
    done
    
    while IFS= read -r d; do
        [[ -d "$d" && ":$PATH:" != *":$d:"* ]] && PATH="$PATH:$d"
    done < <(find "$HOME/.local/bin" -type d 2>/dev/null)
}

#------------------------------------------------------------------------
# Function: _ca_restore_path
# Automatically restore PATH when leaving scope
#------------------------------------------------------------------------
_ca_restore_path() {
    if [[ -n "$OLD_PATH" ]]; then
        PATH="$OLD_PATH"
        unset OLD_PATH
    fi
}

#------------------------------------------------------------------------
# Function: _ca_completion
# Purpose : Enable tab completion for entering commands 
#------------------------------------------------------------------------
_ca_completion() {
    local cur="${COMP_WORDS[COMP_CWORD]}"
    local commands
    
    trap '_ca_restore_path' RETURN
    _ca_add_admin_paths
    
    # Collect possible completions: aliases, functions, builtins, and executables in PATH
    mapfile -t commands < <(compgen -A function -A alias -A builtin -A command -- "$cur")
    # Provide them to bash-completion
    COMPREPLY=("${commands[@]}")
}

#------------------------------------------------------------------------
# Function: _ca_expand_vars
# Purpose : expand variables for aliases so $HOME resolves to /home/jb/ 
#------------------------------------------------------------------------
_ca_expand_vars() {
    local input="$1"
    # Only expand variables like $HOME, $USER, etc. Use 'printf' with parameter expansion to avoid arbitrary command execution.
    # Use a small whitelist: HOME, USER, PWD, SHELL
    local out="$input"
    [[ -n "$HOME" ]] && out="${out//\$HOME/$HOME}"
    [[ -n "$USER" ]] && out="${out//\$USER/$USER}"
    [[ -n "$PWD" ]] && out="${out//\$PWD/$PWD}"
    [[ -n "$SHELL" ]] && out="${out//\$SHELL/$SHELL}"
    printf '%s' "$out"
}

#------------------------------------------------------------------------
# Function: _ca_sourcedtree
# Purpose: Recursively scan .bashrc for ALL files that are sourced. including conditionals.
#------------------------------------------------------------------------
declare -gA SOURCED_FILES_MAP=()   # associative array to avoid duplicates
declare -ga SOURCED_FILES_LIST=()  # optional list preserving order

_ca_sourcedtree() {
    SOURCED_FILES_MAP=()
    SOURCED_FILES_LIST=()
    local file files depth max_depth
    depth=0
    max_depth="${MAX_DEPTH:-5}"
    files=("$BASH_ENV")

if shopt -q login_shell; then
    [[ -d /etc/profile.d ]] && files+=( /etc/profile.d/*.sh )
    [[ -f /etc/profile && -r /etc/profile ]] && files+=( /etc/profile )
else
    # Non-login interactive shell
    [[ -d /etc/bash.bashrc.d ]] && files+=( /etc/bash.bashrc.d/*.sh )
    [[ -f ~/.bashrc && -r ~/.bashrc ]] && files+=( ~/.bashrc )
    [[ -f /etc/bash.bashrc && -r /etc/bash.bashrc ]] && files+=( /etc/bash.bashrc )
fi
    
    for file in "${files[@]}"; do
        _ca_sourcedtree_single "$file" "$depth" "$max_depth"
    done
}

    #-----------------------------------------------------------
    # Internal recursive function
_ca_sourcedtree_single() {
    local file="$1"
    local depth="${2:-0}"
    local max_depth="${3:-5}"
    (( depth > max_depth )) && return

# Expand path
local expanded
expanded=$(_ca_expand_path "$file")
expanded="${expanded%%$'\n'}"   # strip newlines
expanded="${expanded// /}"      # optional: remove spaces if needed

# Skip empty, duplicates, or unreadable files
[[ -z "$expanded" ]] && return
[[ -n ${SOURCED_FILES_MAP["$expanded"]} ]] && return
[[ ! -f "$expanded" || ! -r "$expanded" ]] && return

SOURCED_FILES_MAP["$expanded"]=1
SOURCED_FILES_LIST+=("$expanded")

    local line f left right

    while IFS= read -r line; do
        # Skip comments and empty lines
        [[ -z "$line" || "$line" =~ ^[[:space:]]*# ]] && continue

        # 1️⃣ Standard source/dot
        if [[ $line =~ ^[[:space:]]*(source|\.)[[:space:]]+(.+) ]]; then
            for f in ${BASH_REMATCH[2]}; do
                f=$(_ca_expand_path "$f")
                [[ -f "$f" ]] && _ca_sourcedtree_single "$f" $((depth + 1)) "$max_depth"
            done
            continue
        fi

        # 2️⃣ Conditional: [[ -f FILE ]] && source FILE
        if [[ $line == *"&&"* ]]; then
            left=${line%%&&*}
            right=${line#*&&}
            # Remove leading/trailing spaces
            left=${left##*( )}
            left=${left%%*( )}
            right=${right##*( )}
            right=${right%%*( )}

            # Check if left is [[ -f FILE ]] and right is source FILE
            if [[ $left =~ \[\[[[:space:]]*-f[[:space:]]+([^]]+)\]\] ]] && [[ $right =~ ^source[[:space:]]+(.+) ]]; then
                f=$(_ca_expand_path "${BASH_REMATCH[1]}")
                [[ -f "$f" ]] && _ca_sourcedtree_single "$f" $((depth + 1)) "$max_depth"
            fi
            continue
        fi

        # 3️⃣ For loops: for VAR in FILES; do source $VAR; done
        if [[ $line =~ ^[[:space:]]*for[[:space:]]+[a-zA-Z_][a-zA-Z0-9_]*[[:space:]]+in[[:space:]]+(.+) ]]; then
            for f in ${BASH_REMATCH[1]}; do
                f=$(_ca_expand_path "$f")
                [[ -f "$f" ]] && _ca_sourcedtree_single "$f" $((depth + 1)) "$max_depth"
            done
            continue
        fi

        # 4️⃣ Array sourcing: source "${ARRAY[@]}"
        if [[ $line =~ source[[:space:]]+\"\$\{([a-zA-Z_][a-zA-Z0-9_]*)\[@\]\}\" ]]; then
            local arr_name="${BASH_REMATCH[1]}"
            local elems
            IFS=$'\n' read -r -d '' -a elems < <(eval "printf '%s\n' \"\${$arr_name[@]}\"")
            for f in "${elems[@]}"; do
                f=$(_ca_expand_path "$f")
                [[ -f "$f" ]] && _ca_sourcedtree_single "$f" $((depth + 1)) "$max_depth"
            done
        fi

    done < "$expanded"
}


    #-----------------------------------------------------------
    # Helper: _ca_expand_path
_ca_expand_path() {
    local p="$1"

    # Strip quotes, semicolons, leading/trailing spaces
    p="${p//\"/}"
    p="${p//\'/}"
    p="${p//;/}"
    p="${p##*( )}"
    p="${p%%*( )}"

    # Tilde expansion
    [[ "$p" == "~"* ]] && p="${p/#\~/$HOME}"

    # Replace known environment variables
    [[ -n "$HOME" ]] && p="${p//\$HOME/$HOME}"
    [[ -n "$BASH_ENV" ]] && p="${p//\$BASH_ENV/$BASH_ENV}"

    # Convert to absolute path if possible
    if command -v realpath &>/dev/null && [[ -e "$p" ]]; then
        p=$(realpath "$p" 2>/dev/null || echo "$p")
    fi

    # Remove newlines and trailing spaces
    p="${p//$'\n'/}"
    p="${p%%*( )}"
    printf '%s' "$p"
}


#------------------------------------------------------------------------
# Function: _ca_highlight_script   # _ca_highlight_script "$path-to-script" "<blankspaces>"
# Purpose: Modular syntax highlighting with indentation based on string in $2
#------------------------------------------------------------------------
_ca_highlight_script() {
    local input="$1"
    local indent="    "
    local file="$3"
    local line="$4"
   
    # Construct header for literal text or file
    local header=""
    if [[ -n "$file" && -n "$line" ]]; then
        if [[ "$file" == "main" ]]; then
            header="Interactive shell (not from a file)"
        else    
        header="$file (line $line)"
        fi
    elif [[ -f "$input" ]]; then
        header="$input"
    fi
    
    # Read file if it exists
    local code
    if [[ -f "$input" ]]; then
        code=$(<"$input")
    else
        code="$input"
    fi
    
#----------------------------------------
# Choose bat or batcat, if available
local bat_pager=""
if command -v bat &>/dev/null; then
    bat_pager="bat"
elif command -v batcat &>/dev/null; then
    bat_pager="batcat"
fi

#----------------------------------------
# If bat is available, use it
if [[ -n "$bat_pager" ]]; then
    if [[ -f "$input" ]]; then
        "$bat_pager" --color=always --paging=never --line-range :50 --file-name "$input" "$input" \
        | sed "s/^/$indent/"
    else
        # Input is literal text → use process substitution
        printf "%s" "$code" \
        | "$bat_pager" --color=always --language bash --paging=never --line-range :50 --file-name "$header" - \
        | sed "s/^/$indent/"
    fi
    return
fi

    perl - "$code" "$indent" <<'PERL_CODE'
use strict;
use warnings;

my $content = $ARGV[0];
my $indent = $ARGV[1] // "";

# ANSI colors
my %C = (
    comment   => "\e[36m",
    string    => "\e[96m",
    subshell  => "\e[35m",
    decl      => "\e[32m",
    control   => "\e[93m",
    builtin   => "\e[32m",
    command   => "\e[35m",
    variable  => "\e[33m",
    number    => "\e[34m",
    bracket   => "\e[37m",
    reset     => "\e[0m",
);

# Patterns for syntax highlighting
my @patterns = (
    { regex => qr/("(?:[^"\\]|\\.)*")/,       color => 'string' },
    { regex => qr/('(?:[^'\\]|\\.)*')/,       color => 'string' },
    { regex => qr/\$\((?:[^()]+|(?R))*\)/x,   color => 'subshell' },
    { regex => qr/`[^`]*`/,                    color => 'subshell' },
    { regex => qr/\b(local|declare|export|typeset)\b/, color => 'decl' },
    { regex => qr/\b(if|then|else|elif|fi|for|while|do|done|until|select|case|esac|break|continue)\b/, color => 'control' },
    { regex => qr/\b(function|return|exit|trap|shift|read|mapfile|set|unset)\b/, color => 'builtin' },
    { regex => qr/\b(printf|echo|mkdir|find|grep|sed|awk|cut|sort|head|tail|xargs|cat|touch|chmod|chown|curl|wget)\b/, color => 'command' },
    { regex => qr/\$[A-Za-z0-9_@#*!?_-]+/, color => 'variable' },
    { regex => qr/\b[0-9]+(\.[0-9]+)?\b|0x[0-9A-Fa-f]+/, color => 'number' },
    { regex => qr/\[\[|\]\]|\(\(|\)\)|\(|\)|\{|\}/, color => 'bracket' },
    { regex => qr/#.*/, color => 'comment' },
);

sub highlight {
    my ($line, $indent) = @_;
    foreach my $p (@patterns) {
        $line =~ s/($p->{regex})/$C{$p->{color}}$1$C{reset}/g;
    }
    return $indent . $line;
}

for my $line (split /\n/, $content) {
    print highlight($line, $indent), "\n";
}
PERL_CODE
}

#------------------------------------------------------------------------
# Function: _ca_check_dependencies
# Purpose : Check core and optional dependencies, optionally exit on missing core deps
# Usage   : _ca_check_dependencies needed_deps optional_deps [EXIT_ON_MISSING] 0or1
#------------------------------------------------------------------------
_ca_check_dependencies() {
    local -n required="$1"
    local -n optional="$2"
    local exit_on_missing="${3:-1}"

    local missing_required=()
    local missing_optional=()

    for cmd in "${required[@]}"; do
        command -v "$cmd" >/dev/null 2>&1 || missing_required+=("$cmd")
    done

    for cmd in "${optional[@]}"; do
        command -v "$cmd" >/dev/null 2>&1 || missing_optional+=("$cmd")
    done

    if (( ${#missing_required[@]} )); then
        printf "%b\n" "${RED}Warning: Missing REQUIRED tools: ${missing_required[*]}${RESET}"
        if (( exit_on_missing )); then
            printf "%b\n" "${RED}Cannot continue analysis without core dependencies.${RESET}"
            if [[ "${BASH_SOURCE[0]}" == "$0" ]]; then
                exit 1
            else
                return 1
            fi
        fi
    fi

    return 0
}

#------------------------------------------------------------------------
# Function: _ca_overridden                         
# Purpose : list all commands that override another command
#------------------------------------------------------------------------
_ca_overridden() {
    printf "======== Override Inspection (Mode: -o) ========\n\n"
    _ca_alias_override
    printf "\n"  
    _ca_function_override
    printf "\n"  
    _ca_builtin_override
    printf "\n================ End of list =================== \n"
}

#------------------------------------------------------------------------
# Function: _ca_alias_override                         
# Purpose : list all aliases that override a command
#------------------------------------------------------------------------
_ca_alias_override() { 
    local acmd list akind
    local flag=0
    
    printf "%s├─ Examining aliases to detect overridden commands:\n" "$indent"

    while IFS= read -r acmd; do
        mapfile -t list < <(type -at "$acmd")

        # Deduplicate results
        declare -A seen=()
        local uniq=()
        for akind in "${list[@]}"; do
            [[ ${seen[$akind]} ]] && continue
            uniq+=("$akind")
            seen[$akind]=1
        done

        for akind in "${uniq[@]}"; do
            case "$akind" in
                builtin)
                    printf "%s    ↳ Alias ${YELLOW}%s${RESET} overrides a builtin of the same name.\n" "$indent" "$acmd"
                    flag=1 ;;
                file)
                    printf "%s    ↳ Alias ${YELLOW}%s${RESET} overrides at least one external command of the same name.\n" "$indent" "$acmd"
                    flag=1 ;;
            esac
        done
    done < <(alias | sed -E 's/^alias ([^=]+)=.*/\1/')

    if (( flag == 0 )); then
        printf "%s    ↳ ${CYAN}No command or builtin is overridden.${RESET}\n" "$indent"
    fi
}

#------------------------------------------------------------------------
# Function: _ca_function_override                         
# Purpose : list all functions that override a command
#------------------------------------------------------------------------
_ca_function_override() { 
    local funcmd kind kinds 
    local func_flag=0

    printf "%s├─ Examining functions to detect overridden commands:\n" "$indent"

    # Get list of function names
    while read -r funcmd; do
        mapfile -t kinds < <(type -at "$funcmd")

        for kind in "${kinds[@]}"; do
            case "$kind" in
                alias)
                    printf "%s    ↳ Function ${YELLOW}%s${RESET} overrides an alias of the same name.\n" "$indent" "$funcmd"
                    func_flag=1
                    ;;
                keyword)
                    printf "%s    ↳ Function ${YELLOW}%s${RESET} conflicts with a shell keyword of the same name (keyword takes precedence).\n" "$indent" "$funcmd"
                    func_flag=1
                    ;;
                builtin)
                    printf "%s    ↳ Function ${YELLOW}%s${RESET} overrides a builtin of the same name.\n" "$indent" "$funcmd"
                    func_flag=1
                    ;;
                file)
                    printf "%s    ↳ Function ${YELLOW}%s${RESET} overrides at least one external command of the same name.\n" "$indent" "$funcmd"
                    func_flag=1
                    ;;
            esac
        done
    done < <(declare -F | awk '{print $3}')

    if [[ $func_flag -eq 0 ]]; then
        printf "%s    ↳ No command or builtin is overridden.\n" "$indent"
    fi
}

#------------------------------------------------------------------------
# Function: _ca_builtin_override
# Purpose : list builtins that are disabled and note if external commands replace them
#------------------------------------------------------------------------
_ca_builtin_override() {
    printf "%s├─ Examining disabled builtins to identify any replacement commands:\n" "$indent"

    local b disabled=()

    # Collect disabled builtins
    while read -r b; do
        disabled+=("${b#enable -n }")
    done < <(enable -a | grep '^enable -n ')

    if (( ${#disabled[@]} == 0 )); then
        printf "%s    ↳ No builtins are disabled.\n" "$indent"
        return
    fi

    local name
    for name in "${disabled[@]}"; do
        printf "%s    ↳ Builtin ${YELLOW}%s${RESET} is DISABLED.\n" "$indent" "$name"

        # 1. Alias replacement?
        if alias "$name" &>/dev/null; then
            adef=$(allias "$name")
            printf "%s       • Alias ${YELLOW}'%s' -- '%s'${RESET} now replaces the builtin.\n" "$indent" "$name" "$adef"
            continue
        fi

        # 2. Function replacement?
        if declare -F "$name" &>/dev/null; then
            printf "%s       • Function ${YELLOW}'%s'${RESET} now replaces the builtin.\n" "$indent" "$name"
            continue
        fi

        # 3. External command replacement?
        if command -v "$name" &>/dev/null; then
            local newpath
            newpath=$(command -v "$name")
            printf "%s       • External command ${YELLOW}'%s' - '%s'${RESET} now replaces the builtin.\n" "$indent" "$name" "$newpath"
        else
            printf "%s       • No alias, function, or command replaces ${CYAN}'%s'${RESET}.\n" "$indent" "$name"
        fi
    done
}

#------------------------------------------------------------------------
# Function: _ca_display_scan
# Purpose : scan for SUID / SGID binaries and World-Writable directories 
#------------------------------------------------------------------------
_ca_display_scan() {
    printf "=== SUID/SGID and W-W directories (Mode: -S) ===\n\n"
    _ca_suid_scan
    printf "\n"
    _ca_sgid_scan
    printf "\n"
    _ca_find_world_writable_dirs
    printf "\n================ End of list =================== \n"
}
#------------------------------------------------------------------------
# Function: _ca_sgid_scan
# Purpose : Scan for SGID binaries
#------------------------------------------------------------------------
_ca_sgid_scan() {
    printf "├─ Scanning for SGID binaries:\n"

    while IFS= read -r hitg; do
        printf "    ↳ ${YELLOW}%s${RESET}\n" "$hitg"
    done < <(find / -perm -2000 -type f -exec ls -l {} + 2>/dev/null)
}

#------------------------------------------------------------------------
# Function: _ca_suid_scan
# Purpose : Scan for SUID binaries
#------------------------------------------------------------------------
_ca_suid_scan() {
    printf "├─ Scanning for SUID binaries:\n"

    while IFS= read -r hit; do
        printf "    ↳ ${YELLOW}%s${RESET}\n" "$hit"
    done < <(find / -perm -4000 -type f -exec ls -l {} + 2>/dev/null)
}

#------------------------------------------------------------------------
# Function: _ca_find_world_writable_dirs
# Purpose : Scan for world_writable_dirs
#------------------------------------------------------------------------
_ca_find_world_writable_dirs() {

    printf "├─ Scanning for World-Writable directories:\n"

    # Find world-writable directories
    mapfile -t dirs < <(find / -type d -perm -0002 2>/dev/null)

    for dir in "${dirs[@]}"; do
        [ -d "$dir" ] || continue

        perms=$(stat -c "%A" "$dir")
        owner_g=$(stat -c "%U:%G" "$dir")
        note=""

        # Check sticky bit (position 9)
        sticky="${perms:9:1}"

        if [ "$sticky" = "t" ] || [ "$sticky" = "T" ]; then
            note="${YELLOW}WORLD-WRITABLE + STICKY${RESET}"
            printf "    ↳ ${YELLOW}%-40s %-10s %-20s %-25s${RESET}\n" "$dir" "$perms" "$owner_g" "$note"
        else
            note="${RED}WORLD-WRITABLE!${RESET}"
            printf "    ↳ ${RED}%-40s %-10s %-20s %-25s${RESET}\n" "$dir" "$perms" "$owner_g" "$note"
        fi
    done
}

#------------------------------------------------------------------------
# Function: _ca_writable_dir_in_path
# Purpose : Detect writable directories in $PATH
#------------------------------------------------------------------------
_ca_writable_dir_in_path() {
_ca_restore_path
    printf "========== PATH Inspection (Mode: -p) ==========\n\n"                          
    printf "├─ Examining PATH directory Order and Permissions:\n"
    printf "    ↳ %s%-40s %-15s %-20s %-10s%s\n" "$UNLINE" "Directory" "Perms" "Owner:Group" "Note" "$STOPUNLINE"

#    printf "    ↳ ${UNLINE}%-40s %-15s %-20s %-10s${STOPUNLINE}\n" "Directory" "Perms" "Owner:Group" "Note"
    
    IFS=: read -ra dirs <<< "$PATH"
    for dir in "${dirs[@]}"; do
        [ -d "$dir" ] || continue

        perms=$(stat -c "%A" "$dir")
        owner_g=$(stat -c "%U:%G" "$dir")
        note=""

        # Check if world-writable (other write bit set)
        if [ -w "$dir" ] && [ "${perms:8:1}" = "w" ]; then
            note="${BPURP}WORLD-WRITABLE${RESET}"
            printf "    ↳ ${RED}%-40s %-15s %-20s ${RESET}%-10s\n" "$dir" "$perms" "$owner_g" "$note"
        elif [ -w "$dir" ]; then
            note="Writable"
            printf "    ↳ ${YELLOW}%-40s %-15s %-20s %-10s${RESET}\n" "$dir" "$perms" "$owner_g" "$note"
        else
            printf "    ↳ %-40s %-15s %-20s %-10s\n" "$dir" "$perms" "$owner_g" "$note"
        fi
    done
    printf "\n================ End of list =================== \n"
}

#------------------------------------------------------------------------
# Function: _ca_split_top_level_commands
# Purpose : Split a Bash command line into top-level segments
#------------------------------------------------------------------------
_ca_split_top_level_commands() {
    local input="$1"
    local -n out="$2"
    out=()

    local len=${#input}
    local i=0
    local seg=""
    local c next

    # parser state
    local in_single=0 in_double=0 in_backtick=0
    local paren=0 brace=0 bracket=0
    local dollar_paren=0

    while (( i < len )); do
        c="${input:i:1}"
        next="${input:i+1:1}"

        # -----------------------------
        # QUOTE HANDLING
        # -----------------------------
        if (( in_single )); then
            seg+="$c"
            [[ $c == "'" ]] && in_single=0
            ((i++)); continue
        fi
        if (( in_double )); then
            seg+="$c"
            # handle escaped quotes inside double quotes
            if [[ $c == '"' ]] && [[ "${input:i-1:1}" != "\\" ]]; then
                in_double=0
            fi
            ((i++)); continue
        fi
        if (( in_backtick )); then
            seg+="$c"
            [[ $c == '`' ]] && in_backtick=0
            ((i++)); continue
        fi

        # Enter quotes
        case "$c" in
            "'") in_single=1; seg+="$c"; ((i++)); continue;;
            '"') in_double=1; seg+="$c"; ((i++)); continue;;
            '`') in_backtick=1; seg+="$c"; ((i++)); continue;;
        esac

        # -----------------------------
        # STRUCTURAL NESTING
        # -----------------------------
        case "$c" in
            '(')
                seg+="$c"
                ((paren++))
                # detect $(...)
                if [[ "${input:i-1:1}" == '$' ]]; then ((dollar_paren++)); fi
                ((i++)); continue;;
            ')')
                seg+="$c"
                if (( dollar_paren > 0 )); then
                    ((dollar_paren--))
                else
                    ((paren--))
                fi
                ((i++)); continue;;

            '{') seg+="$c"; ((brace++)); ((i++)); continue;;
            '}') seg+="$c"; ((brace--)); ((i++)); continue;;
            '[') seg+="$c"; ((bracket++)); ((i++)); continue;;
            ']') seg+="$c"; ((bracket--)); ((i++)); continue;;
        esac

        # -----------------------------
        # TOP LEVEL OPERATORS
        # -----------------------------
        # Only if ALL nesting == 0
        if (( paren==0 && brace==0 && bracket==0 && !in_single && !in_double && !in_backtick )); then

            # Operators: || && | ; &
            # Identify multi-char first
            if [[ "$c$next" =~ ^(\|\||&&|;;|;&)$ ]]; then
                out+=("$(printf '%s' "$seg" | sed 's/[[:space:]]*$//')")
                out+=("$c$next")
                seg=""
                ((i+=2)); continue
            fi

            case "$c" in
                '|'|';'|'&')
                    out+=("$(printf '%s' "$seg" | sed 's/[[:space:]]*$//')")
                    out+=("$c")
                    seg=""
                    ((i++)); continue;;
            esac
        fi

        # default → accumulate
        seg+="$c"
        ((i++))
    done

    # final segment
    if [[ -n "$seg" ]]; then
        out+=("$(printf '%s' "$seg" | sed 's/[[:space:]]*$//')")
    fi
}

#------------------------------------------------------------------------
# Function: _ca_parse_commands
# Purpose : Parse a Bash segment into actual executed commands using a conservative tokenizer
#------------------------------------------------------------------------
_ca_parse_commands() {
    local cmdline="$1"
    local -n out_arr="${2:-out_arr}" 2>/dev/null || local -n out_arr="$2"
    [[ -z "$cmdline" ]] && return

    local segments=()
    local seg=""
    local in_single=0 in_double=0
    local in_backtick=0
    local paren=0 brace=0 bracket=0
    local i=0 len=${#cmdline} c next

    # First, split by top-level operators
    while (( i < len )); do
        c="${cmdline:i:1}"
        next="${cmdline:i+1:1}"

        # Handle quotes
        if (( in_single )); then
            seg+="$c"
            [[ $c == "'" ]] && in_single=0
            ((i++)); continue
        fi
        if (( in_double )); then
            seg+="$c"
            if [[ $c == '"' && "${cmdline:i-1:1}" != "\\" ]]; then
                in_double=0
            fi
            ((i++)); continue
        fi
        if (( in_backtick )); then
            seg+="$c"
            [[ $c == '`' ]] && in_backtick=0
            ((i++)); continue
        fi

        case "$c" in
            "'") in_single=1; seg+="$c"; ((i++)); continue;;
            '"') in_double=1; seg+="$c"; ((i++)); continue;;
            '`') in_backtick=1; seg+="$c"; ((i++)); continue;;
            '(') ((paren++)); seg+="$c"; ((i++)); continue;;
            ')') ((paren--)); seg+="$c"; ((i++)); continue;;
            '{') ((brace++)); seg+="$c"; ((i++)); continue;;
            '}') ((brace--)); seg+="$c"; ((i++)); continue;;
            '[') ((bracket++)); seg+="$c"; ((i++)); continue;;
            ']') ((bracket--)); seg+="$c"; ((i++)); continue;;
        esac

        # Top-level operator detection
        if (( paren==0 && brace==0 && bracket==0 && !in_single && !in_double && !in_backtick )); then
            if [[ "$c$next" =~ ^(\|\||&&)$ ]]; then
                [[ -n "$seg" ]] && segments+=("$seg")
                segments+=("$c$next")
                seg=""
                ((i+=2))
                continue
            fi
            case "$c" in
                '|'|';'|'&')
                    [[ -n "$seg" ]] && segments+=("$seg")
                    segments+=("$c")
                    seg=""
                    ((i++))
                    continue;;
            esac
        fi

        # default → accumulate
        seg+="$c"
        ((i++))
    done
    [[ -n "$seg" ]] && segments+=("$seg")

    # Now analyze each segment
    for s in "${segments[@]}"; do
        # Operators
        if [[ "$s" =~ ^(\|\||&&|;|\|)$ ]]; then
            out_arr+=("$s")
            continue
        fi

        # Split segment into command + args respecting quotes (simple)
        local tokens=()
        # Use a safe read to split tokens: rely on word-splitting via eval in a subshell but avoid execution
        # We use printf %q + eval with "set --" to safely split respecting quotes (no expansion)
        local raw="$s"
        # remove leading/trailing whitespace
        raw="${raw#"${raw%%[![:space:]]*}"}"
        raw="${raw%"${raw##*[![:space:]]}"}"
        if [[ -z "$raw" ]]; then
            continue
        fi

        # attempt a conservative split
        local token=""
        local j=0 len_seg=${#raw} ch
        local in_s=0 in_d=0
        while (( j < len_seg )); do
            ch="${raw:j:1}"
            if (( in_s )); then
                token+="$ch"
                [[ $ch == "'" ]] && in_s=0
                ((j++)); continue
            fi
            if (( in_d )); then
                token+="$ch"
                if [[ $ch == '"' && "${raw:j-1:1}" != "\\" ]]; then
                    in_d=0
                fi
                ((j++)); continue
            fi

            case "$ch" in
                "'") in_s=1; token+="$ch";;
                '"') in_d=1; token+="$ch";;
                ' ')
                    if [[ -n "$token" ]]; then
                        tokens+=("$token")
                        token=""
                    fi
                    ;;
                *) token+="$ch";;
            esac
            ((j++))
        done
        [[ -n "$token" ]] && tokens+=("$token")

        # Analyze first token as command
        local cmd_name="${tokens[0]}"
        # normalize: strip surrounding quotes if present
        if [[ "$cmd_name" =~ ^\".*\"$ || "$cmd_name" =~ ^\'.*\'$ ]]; then
            cmd_name="${cmd_name:1:${#cmd_name}-2}"
        fi

        # Skip already seen alias recursion in this parse (avoid infinite)
        if [[ -n "${__CA_SEEN_ALIASES[$cmd_name]}" ]]; then
            out_arr+=("$cmd_name")
            continue
        fi

        if alias "$cmd_name" &>/dev/null; then
            __CA_SEEN_ALIASES[$cmd_name]=1
            out_arr+=("$cmd_name")
            # we do not expand inline here — return token to caller for further analysis
        elif declare -f "$cmd_name" &>/dev/null; then
            __CA_SEEN_ALIASES[$cmd_name]=1
            out_arr+=("$cmd_name")
        else
            out_arr+=("$cmd_name")
        fi
    done
}

#------------------------------------------------------------------------
# Function: _ca_sourced_files
# Purpose: display ALL files that are sourced.
#------------------------------------------------------------------------
_ca_sourced_files() {
    _ca_sourcedtree
    printf "====== Sourced File Inspection (Mode: -s) ======\n\n"
    printf "├─ Searching for files that have been sourced into the enviroment automatically\n" 
    printf "    ↳ %sDiscovered the following files%s:\n" "$UNLINE" "$STOPUNLINE"

    for file in "${SOURCED_FILES_LIST[@]}"; do
        printf "    ↳ ${CYAN}%s${RESET}\n" "$file" 
    done
    printf "\n================ End of list =================== \n"
}        

#------------------------------------------------------------------------
# Function: _ca_show_shadowing
# Purpose : Display path shadowing of a command
#------------------------------------------------------------------------
_ca_show_shadowing() {
    local cmd="$1" cmdpath="$2"
    local shad=() 
    local dir

    IFS=':' read -ra PATH_ARR <<< "$PATH"
    for dir in "${PATH_ARR[@]}"; do
        [[ -x "$dir/$cmd" ]] || continue
        [[ "$dir/$cmd" == "$cmdpath" ]] && continue
        shad+=("$dir/$cmd")   
    done

    (( ${#shad[0]} == 0 )) && return 0

    printf "%s    ↳ Shadowed versions:\n" "$indent"

    local s
for s in "${shad[@]}"; do
    printf "%s    │    ${CYAN}%s${RESET}\n" "$indent" "$s"
done
}

#------------------------------------------------------------------------
# Function: _ca_lookup_package  # usage: _ca_lookup_package "$cmd_path" "$indent"
# Purpose : Lookup package info for a given command path
#------------------------------------------------------------------------
_ca_lookup_package() {
    local cmd_path="$1"
    local indent="${2:-}"  # optional indentation
    local pkg_mgr pkg_name pkg_lines=()

    pkg_mgr=$(_ca_detect_pkg_manager)
    [[ -z "$pkg_mgr" ]] && return 1  # no package manager detected

    case "$pkg_mgr" in
        dpkg)
            pkg_name=$(dpkg -S "$cmd_path" 2>/dev/null | cut -d: -f1 | head -n1)
            if [[ -n "$pkg_name" ]]; then
                while IFS= read -r line; do pkg_lines+=("$line"); done \
                    < <(dpkg-query -W -f='${Package}\n${Version}\n${Maintainer}\n${Description}\n' "$pkg_name" 2>/dev/null)
            fi
            ;;
        rpm)
            pkg_name=$(rpm -qf "$cmd_path" 2>/dev/null)
            if [[ -n "$pkg_name" && "$pkg_name" != "file $cmd_path is not owned by any package" ]]; then
                while IFS= read -r line; do pkg_lines+=("$line"); done \
                    < <(rpm -qi "$pkg_name" | awk '
                    NR==1 { pkg=$3 }
                    NR==2 { ver=$3 }
                    /^Vendor/ {
                    vendor = $3 " " $4      # space between $3 and $4
                    }
                    /^Summary/ {
                    # print from field 3 to end
                    desc = substr($0, index($0, $3))
                    }
                    END {
                    print pkg
                    print ver
                    print vendor
                    print desc
                    }
                ')
            fi
            ;;   
        pacman)
            pkg_name=$(pacman -Qo "$cmd_path" 2>/dev/null | awk '{print $5}')
            if [[ -n "$pkg_name" ]]; then
                while IFS= read -r line; do pkg_lines+=("$line"); done \
                < <(pacman -Qi "$pkg_name" | awk -F': *' '
                    /^Name/        { name=$2 }
                    /^Version/     { ver=$2 }
                    /^Packager/    { maint=$2 }
                    /^Description/ { desc=$2 }
                    END {
                        print name
                        print ver
                        print maint
                        print desc
                    }
               ')
           fi
           ;;
    esac

    # Print package info if available   ----works for apt and rpm
    if [[ -n "${pkg_lines[0]}" ]]; then
        printf "%s    ↳ Package Info:\n" "$indent"
        printf "%s    ⎟    Package: ${CYAN}%s${RESET}\n" "$indent" "${pkg_lines[0]}"
        printf "%s    ⎟    Version: ${CYAN}%s${RESET}\n" "$indent" "${pkg_lines[1]}"
        printf "%s    ⎟    Maintainer: ${CYAN}%s${RESET}\n" "$indent" "${pkg_lines[2]}"
        printf "%s    ⎟    Description: ${CYAN}%s${RESET}\n" "$indent" "${pkg_lines[3]}"
    fi
}

# Detect package manager once
_ca_detect_pkg_manager() {
    if command -v dpkg &>/dev/null; then
        echo "dpkg"
    elif command -v rpm &>/dev/null; then
        echo "rpm"
    elif command -v pacman &>/dev/null; then
        echo "pacman"
    else
        echo ""
    fi
}
 
#------------------------------------------------------------------------

#------------------------------------------------------------------------
# End of script
