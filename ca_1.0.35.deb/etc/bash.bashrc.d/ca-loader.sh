# System-wide activation for ca (non-login interactive shells)

# Only source for interactive shells
case "$-" in
    *i*) ;;
      *) return 0;;
esac

# Source the main script.
if [[ -r /usr/share/ca/ca.sh ]]; then
    source /usr/share/ca/ca.sh
fi
